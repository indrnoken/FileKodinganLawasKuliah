﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraksion
{
   public abstract class ruang2d
    {
        public abstract void gambar();
    }
}
