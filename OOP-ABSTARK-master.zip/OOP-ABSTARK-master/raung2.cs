﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraksion.Interface
{
 public   interface raung2
    {
        void gambar();
    }