﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraksion
{
   public class kotak : ruang2d
    {
        public override void gambar()
        {
            Console.WriteLine(" segi empat");
            Console.WriteLine("sama sisi");
        }
    }
}
