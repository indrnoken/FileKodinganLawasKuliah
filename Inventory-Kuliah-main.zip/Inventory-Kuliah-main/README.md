# Inventory-Kuliah
Aplikasi ini adalah aplikasi manajemen inventori gudang, menggunakan WPF C# untuk kuliah.

## cara mulai awal
- git clone alamatRepositorimu
- git remote -v (untuk cek remote, harus ada origin)
- git remote add repofliw https://github.com/Fliw/Inventory-Kuliah.git
- kalian coding sepuasnya
- git pull repofliw main
- git add .
- git commit -m "pesanku"
- git push origin main
- kirim pull req

## lanjut coding
- git pull repofliw main
- coding sepuasnya
- git pull repofliw master
- git add .
- git commit -m "pesanku"
- git push origin main
- kirim pull req
- ***