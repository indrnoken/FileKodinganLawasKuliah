﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectPenjualan
{
    public class Penjualan
    {
        public string tanggal { get; set; }
        public int nota { get; set; }
        public string nama { get; set; }
        public char jenis { get; set; }
        public double total { get; set; }
       
        
        // PERINTAH: lengkapi property class penjualan, sesuai petunjuk soal



    }
}
