class calculator
{
	static void main (string[] args)
	{
		
	}
	
}